<?php

// include 'includes/user_token.php';


require __DIR__.'/../vendor/autoload.php'; /*autoload ada di vendor sedangkan myfirebase.php ada di includes 
                                            JADI KELUAR DULU dengan cara /../  */

use Kreait\Firebase\Factory;                                             
use Kreait\Firebase\ServiceAccount;

$serviceAccount = ServiceAccount::fromJsonFile(__DIR__.'/tiketsaya-65251-4ae39989fe2c.json'); //dari Google Cloud Platform, pengguna izin-> setelan izin lanjutan->akun layanan

$firebase = (new Factory)
    ->withServiceAccount($serviceAccount)    
    // The following line is optional if the project id in your credentials file
    // is identical to the subdomain of your Firebase project. If you need it,
    // make sure to replace the URL with the URL of your project.
    ->withDatabaseUri('https://tiketsaya-65251.firebaseio.com/') //dari Database TiketSaya di Copy terus tempel sini
    ->create();

$database = $firebase->getDatabase();
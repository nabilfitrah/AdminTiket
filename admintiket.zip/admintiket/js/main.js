var sl_ap = document.getElementById('sl_ap'); //mengambil id sl_ap dan membuat variabel sl_ap

// sl_ap.style.opacity = 0; //ketebalannya 0
// sl_ap.style.visibility = "hidden"; //menjadi tidak terlihat

// function showAdminProfile(){
//     sl_ap.style.opacity = 1; //ketebalan 1
//     sl_ap.style.visibility = "visible" //menjadi terlihat
//     sl_ap.style.transition = "all 0.8s"; //transisi selama 0.8detik
// };

// function hideAdminProfile(){
//     sl_ap.style.opacity = 0;
//     sl_ap.style.visibility = "hidden";
//     sl_ap.style.transition = "all 0.8s";
// };

// function agar tombol Replace bisa mengambil gambar yang awalnya dari #image_file
$(function(){
    $("#open_file").click(function() {
        $('#image_file').click();
    });
});
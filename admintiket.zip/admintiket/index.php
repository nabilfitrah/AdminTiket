<?php

    function jajan($uang_saya, $belanja){
       
        if($uang_saya > $belanja) {
            $sisa_uang = $uang_saya - $belanja;
            echo "Kembalianya" . $sisa_uang;
        }
        else {
            echo "Uang Tidak Cukup";
        }
    }

    jajan(100,150);

?>
<?php
    include 'includes/myfirebase.php';

    $username_admin_url = $_GET['username_url'];  //username_url dari href yang Delete User akhirannya

    $reference = 'Admin/'.$username_admin_url;

    //upload menuju server
    $pushData = $database->getReference($reference)->remove();

    //lempar ke customer.php
    header('location: includes/user_destroy.php');

?>